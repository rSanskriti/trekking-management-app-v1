from app import app
from application.database import db
from application.models import User


with app.app_context():
    db.drop_all()
    db.create_all()

    admin = User.query.filter_by(username='admin').first()
    if admin is None:
        admin_user = User(username='admin', password='admin123', role='Admin')
        db.session.add(admin_user)
        db.session.commit()

    print("Database reset complete. Tables recreated with updated schema.")
    print("Admin login -> username: admin / password: admin123")